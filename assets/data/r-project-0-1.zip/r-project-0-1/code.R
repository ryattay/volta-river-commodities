## Head ####

## METADATA
## title: Volta River Commodities Data R Project
## summary: Transforms raw CSV files into a single dataset available as a CSV or JSON file.

## PACKAGES
library("tidyverse")
library("jsonlite")

## Clean and Transform Data ####

## Import Data

station.month <- read.csv("./data/station-month.csv", header=TRUE, stringsAsFactors = FALSE)
names(station.month)[1] <- c("entry")

station.quarter <- read.csv("./data/station-quarter.csv", header=TRUE, stringsAsFactors = FALSE)
names(station.quarter)[1] <- c("entry")

district.month <- read.csv("./data/district-month.csv", header=TRUE, stringsAsFactors = FALSE)
names(district.month)[1] <- c("entry")

district.quarter <- read.csv("./data/district-quarter.csv", header=TRUE, stringsAsFactors = FALSE)
names(district.quarter)[1] <- c("entry")

province.quarter <- read.csv("./data/province-quarter.csv", header=TRUE, stringsAsFactors = FALSE)
names(province.quarter)[1] <- c("entry")

region.month <- read.csv("./data/region-month.csv", header=TRUE, stringsAsFactors = FALSE)
names(region.month)[1] <- c("entry")

region.year <- read.csv("./data/region-year.csv", header=TRUE, stringsAsFactors = FALSE)
names(region.year)[1] <- c("entry")

## Merge datasets into one data frame

internal <- rbind(district.month, district.quarter, province.quarter, region.month, region.year, station.month, station.quarter)
rm("district.month", "district.quarter", "province.quarter", "region.month", "region.year", "station.month", "station.quarter")

internal$month <- as.integer(internal$month)

internal[is.na(internal)] <- ""

## Clean region field

internal$region <- gsub("nt", "northern territories", internal$region)

## Clean district field

internal <- internal %>%
  mutate(
    district = case_when(
      district == "kratchi" ~ "krachi",
      district == "tumu" ~ "lawra-tumu", # are these different areas?
      TRUE ~ as.character(district)
    )
  )

## Clean station field

internal <- internal %>%
  mutate(
    station = case_when(
      station == "dakar mouth frontier" ~ "dakar", # is dakar mouth different from dakar river?
      station == "dakar river station" ~ "dakar",
      station == "krupi" ~ "grubi", # is krupi a misspelled version of grubi?
      station == "Tamale" ~ "tamale",
      TRUE ~ as.character(station)
    )
  )

## Clean unit field

internal <- internal %>%
  mutate(
    unit = case_when(
      unit == "50 lb" ~ "50 lb loads",
      unit == "bag" ~ "bags",
      unit == "bags or loads" ~ "bags|loads",
      unit == "bales or loads" ~ "bales|loads",
      unit == "bales or parcels" ~ "bales|parcels",
      unit == "ball" ~ "balls",
      unit == "bar" ~ "bars",
      unit == "barrel" ~ "barrels",
      unit == "basket" ~ "baskets",
      unit == "box" ~ "boxes",
      unit == "box or case" ~ "boxes|cases",
      unit == "bundle or packet" ~ "bundles|packets",
      unit == "bundles or loads" ~ "bundles|loads",
      unit == "bundles or packets" ~ "bundles|packets",
      unit == "carrier load" ~ "carrier loads",
      unit == "case" ~ "cases",
      unit == "cases or loads" ~ "cases|loads",
      unit == "cases or tins" ~ "cases|tins",
      unit == "cwt?" ~ "cwt",
      unit == "cwts" ~ "cwt",
      unit == "donkey load" ~ "donkey loads",
      unit == "dozen" ~ "dozens",
      unit == "dozen or packets" ~ "dozens|packets",
      unit == "drum" ~ "drums",
      unit == "keg" ~ "kegs",
      unit == "keg or tin" ~ "kegs|tins",
      unit == "lbs?" ~ "lbs",
      unit == "load" ~ "loads",
      unit == "loads or bags" ~ "bags|loads",
      unit == "loads or bales" ~ "bales|loads",
      unit == "loads or bundles" ~ "bundles|loads",
      unit == "loads or cases" ~ "cases|loads",
      unit == "packets and cases" ~ "cases|packets",
      unit == "packets or bundles" ~ "bundles|packets",
      unit == "packets or dozen" ~ "dozens|packets",
      unit == "packets|bundles" ~ "bundles|packets",
      unit == "parcel" ~ "parcels",
      unit == "parcel or bales" ~ "bales|parcels",
      unit == "single" ~ "singles",
      unit == "tin" ~ "tins",
      unit == "tin or box" ~ "boxes|tins",
      unit == "tusk" ~ "tusks",
      TRUE ~ as.character(unit)
    )
  )

## Clean direction field

internal <- internal %>%
  mutate(
    direction = case_when(
      direction == "exports" ~ "export",
      direction == "export across the frontier to togoland" ~ "export",
      direction == "export from left bank" ~ "export",
      direction == "from krupi to togo" ~ "export",
      direction == "from togoland to nt" ~ "import to northern territories",
      direction == "from togoland to south" ~ "import to southern territories",
      direction == "import across the frontier from togoland" ~ "import",
      direction == "foreign territory to nt" ~ "import to northern territories",
      direction == "from left bank" ~ "from left to right bank",
      direction == "left to right" ~ "from left to right bank",
      direction == "left to right bank" ~ "from left to right bank",
      direction == "right to left" ~ "from right to left bank",
      direction == "right to left bank" ~ "from right to left bank",
      TRUE ~ as.character(direction)
    )
  )

## Clean good field

## Standardize spelling of goods

internal <- internal %>% 
  mutate(
    good = case_when(
      good == "bash boxes" ~ "cash boxes",
      good == "basin" ~ "basins",
      good == "basins or plates" ~ "basins|plates",
      good == "basin?" ~ "basins",
      good == "bicycle" ~ "bicycles",
      good == "boot" ~ "boots",
      good == "brass or copper rods" ~ "brass and copper rods",
      good == "brass pan" ~ "brass pans",
      good == "caps gun" ~ "caps",
      good == "clay plate" ~ "clay plates",
      good == "cloth and blankets" ~ "blankets|cloth",
      good == "coal jar" ~ "coal tar",
      good == "cooking pan" ~ "cooking pans",
      good == "copper wire" ~ "copper wires",
      good == "corn and millet" ~ "corn|millet",
      good == "corn and wheat" ~ "corn|wheat",
      good == "corrigate iron" ~ "corrugated iron",
      good == "cotton piece goods" ~ "cotton goods",
      good == "cow hide" ~ "cow hides",
      good == "cow hides and leather skins" ~ "cow hides|leather skins",
      good == "cow skins" ~ "cow hides",
      good == "cups and saucers" ~ "cups|saucers",
      good == "cutlass" ~ "cutlasses",
      good == "dog" ~ "dogs",
      good == "double barrel gun" ~ "double barrel guns",
      good == "english cloth and blankets" ~ "english blankets|cloth",
      good == "flint stones" ~ "flint",
      good == "grey baft?" ~ "grey baft",
      good == "ground pepper" ~ "ground peppers",
      good == "groudnuts" ~ "groundnuts",
      good == "gun and powder" ~ "guns|gunpowder",
      good == "gun powder" ~ "gunpowder",
      good == "handkerchief" ~ "handkerchiefs",
      good == "hat" ~ "hats",
      good == "hair oil or pomades" ~ "hair oil|pomade",
      good == "horse" ~ "horses",
      good == "horses|donkeys" ~ "donkeys|horses",
      good == "iron sheet" ~ "iron sheets",
      good == "kerosene oil" ~ "kerosene",
      good == "lantern" ~ "lanterns",
      good == "lavendar?" ~ "lavender",
      good == "lead bars flint and stone" ~ "lead bars|flint|stones",
      good == "leather skins and cow hides" ~ "cow hides|leather skins",
      good == "iron hooks and machinery" ~ "iron hooks|machines",
      good == "machine" ~ "machines",
      good == "machinery" ~ "machines",
      good == "matchets or cutlasses" ~ "cutlasses|matchets",
      good == "mirror" ~ "mirrors",
      good == "mouth organ" ~ "mouth organs",
      good == "native cloth and blankets" ~ "native blankets|cloth",
      good == "paint" ~ "paints",
      good == "paint?" ~ "paints",
      good == "perfumeries" ~ "perfume",
      good == "perfumery" ~ "perfume",
      good == "perfumes" ~ "perfume",
      good == "pipes smoking" ~ "pipes",
      good == "planks or boards" ~ "boards|planks",
      good == "plates and basins" ~ "basins|plates",
      good == "pocket handkerchiefs" ~ "handkerchiefs",
      good == "poultries" ~ "poultry",
      good == "print" ~ "prints",
      good == "rope" ~ "ropes",
      good == "sandals?" ~ "sandals",
      good == "sheep and goats" ~ "goats|sheep",
      good == "shirting?" ~ "shirting",
      good == "skin" ~ "skins",
      good == "soap bars" ~ "soap",
      good == "soap toilet" ~ "soap",
      good == "steel iron and hoes" ~ "hoes|steel iron",
      good == "string and rope" ~ "ropes|strings",
      good == "strings beads" ~ "beads|strings",
      good == "strings rubber beads" ~ "rubber beads|strings",
      good == "tea cup|saucer" ~ "cups|saucers",
      good == "toilet soap" ~ "soap",
      good == "towel" ~ "towels",
      good == "towel bath" ~ "towels",
      good == "umbrella" ~ "umbrellas",
      good == "wheats" ~ "wheat",
      good == "yarns" ~ "yarn",
      TRUE ~ as.character(good)
    )
  )

## Separate good description from name

internal$description.new <- ""
internal <- internal %>% 
  mutate(
    description.new = case_when(
      good == "blue baft" ~ "blue",
      good == "brass and copper rods" ~ "brass|copper",
      good == "brass basins" ~ "brass",
      good == "brass or copper rods" ~ "brass|copper",
      good == "brass pans" ~ "brass",
      good == "brass rods" ~ "brass",
      good == "clay pipes" ~ "clay",
      good == "clay plates" ~ "clay",
      good == "copper rods" ~ "copper",
      good == "copper wires" ~ "copper",
      good == "double barrel guns" ~ "double barrel",
      good == "dried fish" ~ "dried",
      good == "dried meat" ~ "dried",
      good == "dry cassava" ~ "dry",
      good == "earthen bowls" ~ "earthenware",
      good == "earthen plates" ~ "earthenware",
      good == "enamel basins" ~ "enamelware",
      good == "enamel bowls" ~ "enamelware",
      good == "enamel pans" ~ "enamelware",
      good == "enamel plates" ~ "enamelware",
      good == "flint lock gun" ~ "flint lock",
      good == "flooring boards" ~ "for flooring",
      good == "government carriers and soldiers" ~ "government carriers and soldiers",
      good == "grey baft" ~ "gray",
      good == "ground peppers" ~ "ground",
      TRUE ~ as.character(description.new)
    )
  )

## Merge description.new and description columns

internal$description <- ifelse(internal$description == "", paste0(internal$description.new),
                               ifelse(internal$description.new == "", paste0(internal$description), paste0(internal$description,"; ",internal$description.new)))
internal$description.new <- NULL

## Delete descriptions in good field

internal <- internal %>%
  mutate(
    good = case_when(
      good == "blue baft" ~ "baft",
      good == "brass and copper rods" ~ "rods",
      good == "brass basins" ~ "basins",
      good == "brass or copper rods" ~ "rods",
      good == "brass pans" ~ "pans",
      good == "brass rods" ~ "rods",
      good == "clay pipes" ~ "pipes",
      good == "clay plates" ~ "plates",
      good == "copper rods" ~ "rods",
      good == "copper wires" ~ "wires",
      good == "double barrel guns" ~ "guns",
      good == "dried fish" ~ "fish",
      good == "dried meat" ~ "meat",
      good == "dry cassava" ~ "cassava",
      good == "earthen bowls" ~ "bowls",
      good == "earthen plates" ~ "plates",
      good == "enamel basins" ~ "basins",
      good == "enamel bowls" ~ "bowls",
      good == "enamel pans" ~ "pans",
      good == "enamel plates" ~ "plates",
      good == "flint lock gun" ~ "guns",
      good == "flooring boards" ~ "boards",
      good == "government carriers and soldiers" ~ "persons",
      good == "grey baft" ~ "baft",
      good == "ground peppers" ~ "peppers",
      TRUE ~ as.character(good)
    )
  )

## Create origin field for goods

internal$origin.new <- ""
internal <- internal %>%
  mutate(
    origin.new = case_when(
      good == "bush rabbits" ~ "bush",
      good == "english cloth" ~ "england",
      good == "english cloth|blankets" ~ "england",
      good == "english soap" ~ "england",
      TRUE ~ as.character(origin.new)
    )
  )

## Merge origin.new and origin columns

internal$origin <- ifelse(internal$origin == "", paste0(internal$origin.new),
                          ifelse(internal$origin.new == "", paste0(internal$origin), paste0(internal$origin,"; ",internal$origin.new)))
internal$origin.new <- NULL


## Delete origins in good field

internal <- internal %>%
  mutate(
    good = case_when(
      good == "bush rabbits" ~ "rabbits",
      good == "english cloth" ~ "cloth",
      good == "english cloth|blankets" ~ "cloth|blankets",
      good == "english soap" ~ "soap",
      TRUE ~ as.character(good)
    )
  )

## Clean description field

## Standardize spellings of descriptions

internal <- internal %>%
  mutate(
    description = case_when(
      description == "brass and copper" ~ "brass|copper",
      description == "dry" ~ "dried",
      description == "enamel" ~ "enamelware",
      description == "european articles; brass|copper" ~ "european; brass|copper",
      description == "european articles" ~ "european",
      description == "grey" ~ "gray",
      description == "hausa cloth" ~ "hausa",
      TRUE ~ as.character(description)
    )
  )

## Create origin.new field

internal$origin.new <- ""
internal <- internal %>%
  mutate(
    origin.new = case_when(
      description == "country" ~ "country",
      description == "european" ~ "european",
      description == "european; brass|copper" ~ "european",
      description == "hausa" ~ "hausa",
      description == "indian" ~ "indian",
      description == "moshi" ~ "moshi",
      description == "native" ~ "native",
      TRUE ~ as.character(origin.new)
    )
  )

## Merge origin.new and origin columns

internal$origin <- ifelse(internal$origin == "", paste0(internal$origin.new),
                          ifelse(internal$origin.new == "", paste0(internal$origin), paste0(internal$origin,"; ",internal$origin.new)))
internal$origin.new <- NULL

## Delete origins in description field

internal <- internal %>%
  mutate(
    description = case_when(
      description == "country" ~ "",
      description == "european" ~ "",
      description == "european; brass|copper" ~ "brass|copper",
      description == "hausa" ~ "",
      description == "indian" ~ "",
      description == "moshi" ~ "",
      description == "native" ~ "",
      TRUE ~ as.character(description)
    )
  )

## Clean origin field

internal <- internal %>%
  mutate(
    origin = case_when(
      origin == "mossi" ~ "moshi",
      TRUE ~ as.character(origin)
    )
  )


## Export ####

## Prepare for export

internal$entry <- NULL

internal$good <- str_replace_all(internal$good, coll("?"), "")
internal$description <- str_replace_all(internal$description, coll("?"), "")
internal$unit <- str_replace_all(internal$unit, coll("?"), "")

internal <- internal[!(internal$good==""),]
internal <- internal[!(internal$good=="persons"),]

## Export as csv

internal %>%
  write.csv("output/data-0-1.csv", row.names = FALSE)

## Export as json

internal %>%
  toJSON() %>%
  write_lines ("output/data-0-1.json")